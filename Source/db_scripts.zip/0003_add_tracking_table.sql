select 'create table TRACKING' 
from dual
;
-- Create sequence 
select 'create sequence "sq_TRACKING' 
from dual
