select 'create loaded materials' 
from dual
;
-- Create sequence 
select 'q_CURRENT_LOADED_MATERIALS' 
from 
dual