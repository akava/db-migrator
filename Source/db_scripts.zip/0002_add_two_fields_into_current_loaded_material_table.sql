select 'current_loaded_material' 
from dual
;
select 'alter table  current_loaded_material ' 
from dual